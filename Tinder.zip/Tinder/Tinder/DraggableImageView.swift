//
//  DraggableImageView.swift
//  Tinder
//
//  Created by NicoleA on 4/27/17.
//  Copyright © 2017 Agetas. All rights reserved.
//

import UIKit

class DraggableImageView: UIView {

    @IBOutlet private weak var imageView: UIImageView!
    
    var image: UIImage! {
        get{return imageView.image}
        set{imageView.image = newValue}
    }
    
    var photoOriginalCenter: CGPoint!
    var rotationAngleInRadians = Measurement(value: 45, unit: UnitAngle.degrees)
        .converted(to: .radians).value
    
    let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(DraggableImageView.didPanPhoto(_:)))
    
    //imageView.addGestureRecognizer(panGestureRecognizer)
    
    let rotationGestureRecognizer = UIRotationGestureRecognizer(target: self, action:
        #selector (DraggableImageView.didRotatePhoto(_:)))
    
    @IBAction func didPanPhoto(_ sender: UIPanGestureRecognizer) {
        //  let location = sender.location(in: imageView)
        // let velocity = sender.velocity(in: imageView)
        let translation = sender.translation(in: imageView)
        
        if sender.state == .began {
            photoOriginalCenter = imageView.center
            print("Gesture began")
        } else if sender.state == .changed {
            imageView.center = CGPoint(x: photoOriginalCenter.x + translation.x, y: photoOriginalCenter.y)
            print("Gesture is changing")
        } else if sender.state == .ended {
            imageView.center = photoOriginalCenter
            print("Gesture ended")
        }
    }
    
    @IBAction func didRotatePhoto(_ sender: UIRotationGestureRecognizer)
    {
        //let velocity = sender.velocity
        //let rotation = sender.rotation
        let imageView = sender.view as! UIImageView
        
        imageView.transform = (sender.view?.transform)!.rotated(by: sender.rotation)
        
      /*  if velocity > 0 {
            imageView.transform = stretchAndRotate
        }
        else if velocity < 0{
                imageView.transform = stretchAndRotate
        }*/
        
        sender.rotation = 0
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
