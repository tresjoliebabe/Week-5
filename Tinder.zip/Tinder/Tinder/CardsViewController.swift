//
//  ViewController.swift
//  Tinder
//
//  Created by NicoleA on 4/25/17.
//  Copyright © 2017 Agetas. All rights reserved.
//

import UIKit

class CardsViewController: UIViewController, UIGestureRecognizerDelegate {
    
    @IBOutlet var cardsView: UIView!
    
    @IBOutlet weak var draggableImageView: DraggableImageView!
    
    @IBOutlet var rotationGestureRecognizer: UIRotationGestureRecognizer!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        rotationGestureRecognizer.delegate = self
        //self.draggableImageView.addGestureRecognizer(rotationGestureRecognizer)
        
        cardsView.addSubview(draggableImageView)
        
            draggableImageView.isUserInteractionEnabled = true
        
            draggableImageView.center = cardsView.center
        
            draggableImageView.image = UIImage(named: "ryan")
        
            draggableImageView = DraggableImageView(frame: CGRect(x:53, y:181, width:view.bounds.width, height:181))
        
        
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        if (gestureRecognizer is UIPanGestureRecognizer || gestureRecognizer is UIRotationGestureRecognizer) {
            return true
        } else {
            return false
        }
    }

    
    
    
    
}

